from django.db import models
class GameState(models.Model):
    bravery=models.IntegerField(default=1)
    stage=models.IntegerField(default=1)
    beloved=models.CharField(max_length=100,blank=True)
