from django.shortcuts import render,redirect
from .models import GameState
import random

def get_state():
    s=GameState.objects.first()
    if not s: s=GameState.objects.create()
    return s

def start(request):
    s=get_state()
    return render(request,'start.html',{'s':s})

def stage1(request):
    s=get_state()
    outcome=random.choice(['win','draw','lose'])
    if outcome=='win':
        s.bravery+=1; s.stage=2
    elif outcome=='lose':
        s.bravery-=1
    s.save()
    if s.bravery<=0: return render(request,'end.html',{'status':'coward'})
    if s.stage==2: return redirect('/stage2/')
    return render(request,'stage1.html',{'outcome':outcome,'s':s})

def stage2(request):
    s=get_state()
    if request.method=='POST':
        s.beloved=request.POST.get('beloved','')
        outcome=random.choice(['win','lose'])
        if outcome=='win': s.bravery+=1
        else: s.bravery-=1
        s.stage=3; s.save()
        if s.bravery<=0: return render(request,'end.html',{'status':'coward'})
        return redirect('/stage3/')
    return render(request,'stage2.html',{})

def stage3(request):
    s=get_state()
    outcome=random.choice(['win','lose'])
    if outcome=='win': s.bravery+=1
    else: s.bravery-=1
    s.save()
    if s.bravery<=0: return render(request,'end.html',{'status':'coward'})
    if s.bravery>=3: return render(request,'end.html',{'status':'hero','beloved':s.beloved})
    return render(request,'end.html',{'status':'knight'})
