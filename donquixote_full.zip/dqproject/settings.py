SECRET_KEY='dev'
DEBUG=True
ALLOWED_HOSTS=[]
INSTALLED_APPS=['django.contrib.staticfiles','game']
ROOT_URLCONF='dqproject.urls'
MIDDLEWARE=[]
STATIC_URL='/static/'
import os
BASE_DIR=os.path.dirname(os.path.dirname(__file__))
TEMPLATES=[{'BACKEND':'django.template.backends.django.DjangoTemplates','DIRS':[os.path.join(BASE_DIR,'templates')],'APP_DIRS':True}]
DATABASES={'default':{'ENGINE':'django.db.backends.sqlite3','NAME':os.path.join(BASE_DIR,'db.sqlite3')}}
