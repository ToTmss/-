from django.urls import path
from game import views
urlpatterns=[path('',views.start),path('stage1/',views.stage1),path('stage2/',views.stage2),path('stage3/',views.stage3)]
